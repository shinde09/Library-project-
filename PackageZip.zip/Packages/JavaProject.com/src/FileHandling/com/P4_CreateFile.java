package FileHandling.com;

import java.io.File;
import java.io.IOException;

public class P4_CreateFile {

	public static void main(String[] args) {
		File file=new File("D:\\FileHandling\\File4.txt");
		try {
			if (file.createNewFile()) {
				System.out.println("File successfully Created");
			} else {
			 System.out.println("File Already exists");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
