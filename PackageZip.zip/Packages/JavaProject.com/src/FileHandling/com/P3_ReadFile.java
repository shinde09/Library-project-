package FileHandling.com;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class P3_ReadFile {

	public static void main(String[] args) throws FileNotFoundException {

		File file=new File("D:\\FileHandling//file3.txt");
		Scanner sc1=new Scanner(file);
		while (sc1.hasNextLine()) {
			String line=sc1.nextLine();
			System.out.println(line);
		}
		sc1.close();
		
	}

}
