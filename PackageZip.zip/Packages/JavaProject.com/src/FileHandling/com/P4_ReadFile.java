package FileHandling.com;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class P4_ReadFile {

	public static void main(String[] args){
		File file=new File("D:\\FileHandling\\File4.txt");
		try {
			Scanner sc1=new Scanner(file);
			while (sc1.hasNextLine()) {
				String line=sc1.nextLine();
				System.out.println(line);
			}
			sc1.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		

	}

}
