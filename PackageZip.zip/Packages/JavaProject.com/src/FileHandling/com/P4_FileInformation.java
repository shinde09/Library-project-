package FileHandling.com;

import java.io.File;

public class P4_FileInformation {

	public static void main(String[] args) {

		File file=new File("D:\\FileHandling\\File4.txt");
		if (file.exists()) {
			System.out.println(file.getName());
			System.out.println(file.getAbsolutePath());
			System.out.println(file.canRead());
			System.out.println(file.canWrite());
			System.out.println(file.length());
		} else {
            System.out.println("File not Exists");
		}
	}

}
