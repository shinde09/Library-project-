package FileHandling.com;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class P1_FileWrite {

	public static void main(String[] args) throws IOException {

		File myFile=new File("D:File.txt");
		FileWriter fw=new FileWriter("D:File.txt");
		fw.write("Welcome to NSEIT ...!");
		fw.close();
		
	}

}
