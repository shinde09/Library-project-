package FileHandling.com;

import java.io.File;
import java.io.IOException;

public class P3_CreateFile {

	public static void main(String[] args) throws IOException {

		File file=new File("D:\\FileHandling//file3.txt");
		if (file.createNewFile()) {
			System.out.println(file.getName()+" File successfully created");
		} else {
                System.out.println("File already exists");
		}
	}

}
