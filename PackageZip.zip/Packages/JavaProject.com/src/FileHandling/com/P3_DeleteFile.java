package FileHandling.com;

import java.io.File;

public class P3_DeleteFile {

	public static void main(String[] args) {

		File file=new File("D:\\FileHandling//File3.txt");
		if (file.delete()) {
			System.out.println("File is Deleted");
		} else {
                System.out.println("Some problem to delete file");
		}
	}

}
