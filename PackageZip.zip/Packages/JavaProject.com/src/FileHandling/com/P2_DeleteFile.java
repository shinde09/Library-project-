package FileHandling.com;

import java.io.File;

public class P2_DeleteFile {

	public static void main(String[] args) {
		File file=new File("D:\\FileHandling//File1.txt");
		if (file.delete()) {
			System.out.println("File deleted :"+file.getName());
		} else {
             System.out.println("Some problem to delete");
		}

	}

}
