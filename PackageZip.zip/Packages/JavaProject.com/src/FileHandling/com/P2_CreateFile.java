package FileHandling.com;

import java.io.File;
import java.io.IOException;

public class P2_CreateFile {

	public static void main(String[] args) throws IOException {

		File file=new File("D:\\FileHandling//File1.txt");
		if (file.createNewFile()) {
			System.out.println(file.getName()+" File Create Successfully...!");
		} else {
             System.out.println("File already Exist..!");
		}
	}

}
