package FileHandling.com;

import java.io.File;

public class P2_FileInformation {

	public static void main(String[] args) {

		File file=new File("D:\\FileHandling//File1.txt");
		if (file.exists()) {
			System.out.println("File Name "+file.getName());
			System.out.println("File Path "+file.getAbsolutePath());
			System.out.println("Writeable "+file.canWrite());
			System.out.println("Readable "+file.canRead());
			System.out.println("File size "+file.length());
		} else {
            System.out.println("File not exist..!");
		}
	}

}
