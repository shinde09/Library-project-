package FileHandling.com;

import java.io.FileWriter;
import java.io.IOException;

public class P4_WriteFile {

	public static void main(String[] args){
		try {
			FileWriter fw1=new FileWriter("D:\\FileHandling\\File4.txt");
			fw1.write("Welcome to NSEIT..!");
			System.out.println("File write successfully");
			fw1.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		

	}

}
