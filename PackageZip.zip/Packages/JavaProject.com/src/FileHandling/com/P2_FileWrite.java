package FileHandling.com;

import java.io.FileWriter;
import java.io.IOException;

public class P2_FileWrite {

	public static void main(String[] args) throws IOException {

		FileWriter fw1=new FileWriter("D:\\FileHandling//File1.txt");
		fw1.write("Welcome to NSEIT..!");
		fw1.close();
		System.out.println("File Writting Successfull");
	}

}
