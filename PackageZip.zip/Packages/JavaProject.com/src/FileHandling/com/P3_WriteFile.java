package FileHandling.com;

import java.io.FileWriter;
import java.io.IOException;

public class P3_WriteFile {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileWriter fw1=new FileWriter("D:\\\\FileHandling//file3.txt");
		fw1.write("Welcome to Mumbai...!");
		System.out.println("File Write successfully");
		fw1.close();
		

	}

}
