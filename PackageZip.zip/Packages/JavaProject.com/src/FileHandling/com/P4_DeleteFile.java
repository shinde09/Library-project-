package FileHandling.com;

import java.io.File;

public class P4_DeleteFile {

	public static void main(String[] args) {
		File file=new File("D:\\FileHandling\\File4.txt");
		if (file.delete()) {
			System.out.println("File Deleted...!");
		} else {
             System.out.println("some problem to delete file..!");
		}
	}

}
