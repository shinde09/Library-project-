package FileHandling.com;

import java.io.File;

public class P3_FileInformation {

	public static void main(String[] args) {

		File file=new File("D:\\FileHandling//file3.txt");
		System.out.println(file.getName());
		System.out.println(file.getAbsolutePath());
		System.out.println(file.canRead());
		System.out.println(file.canWrite());
		System.out.println(file.length());

	}

}
