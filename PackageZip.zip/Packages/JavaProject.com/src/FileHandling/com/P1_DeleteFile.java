package FileHandling.com;

import java.io.File;

public class P1_DeleteFile {

	public static void main(String[] args) {

		File myFile=new File("D:File.txt");
		if (myFile.delete()) {
			System.out.println("File deleted :"+myFile.getName());
		} else {
             System.out.println("Some problem to delete");
		}
	}

}
