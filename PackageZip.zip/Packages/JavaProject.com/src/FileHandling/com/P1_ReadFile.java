package FileHandling.com;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class P1_ReadFile {

	public static void main(String[] args) throws FileNotFoundException {

		File myFile=new File("D:File.txt");
		Scanner sc=new Scanner(myFile);
		while (sc.hasNextLine()) {
			String line=sc.nextLine();
			System.out.println(line);
		}
		sc.close();
	}

}
