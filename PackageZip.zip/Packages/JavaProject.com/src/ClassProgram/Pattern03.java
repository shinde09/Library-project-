package ClassProgram;

public class Pattern03 {

	public static void main(String[] args) {

		int line=5,star=1,space=4;
		for (int i = 0; i < line; i++) {
			for (int j = 0; j < space; j++) {
				System.out.print(" ");
			}
			for (int j = 0; j < star; j++) {
				System.out.print(" *");
			}
			System.out.println();
			star++;
			space--;
		}
	}

}
