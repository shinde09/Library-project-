package ClassProgram;

public class StringSplit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String courses="HTML_CSS_JAVA_MANUAL_REACT_ANGULAR";
	System.out.println(courses);
	String []data=courses.split("_");
	for (int i = 0; i < data.length; i++) {
		System.out.print(data[i]+" ");
	}

	}

}
