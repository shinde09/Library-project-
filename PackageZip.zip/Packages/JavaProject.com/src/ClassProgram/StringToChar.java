package ClassProgram;

public class StringToChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String city="Mumbai@123";
		char[]carray=city.toCharArray();
		for (int i = 0; i < carray.length; i++) {
			System.out.print(carray[i]+" ");

		}
		System.out.println();
		for (int i = carray.length-1; i >=0 ; i--) {
			System.out.print(carray[i]+" ");

		}

	}

}
