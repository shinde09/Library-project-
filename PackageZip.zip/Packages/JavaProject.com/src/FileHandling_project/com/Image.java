package FileHandling_project.com;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

public class Image {
	public static void main(String[] args) {
		System.out.println("First Head Book");
		File f = new File ("D:\\Project1\\Books\\Java\\FirstHead.jpg");
		
		Desktop d = Desktop.getDesktop();
		try {
			d.open(f);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}


}
