package FileHandling_project.com;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Books1 {
	 public void readMindsetBook() {	
		  File f = new File("D:\\Project1\\Books\\Motivational\\Mindset.txt");
		  
		  try {
			Scanner sc  = new Scanner(f);
			while(sc.hasNextLine()) {
				System.out.println(sc.nextLine());
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		  }
	  
		  
		  public void readRichDadAndPoorDadBook() {
			  File f = new File("D:\\Project1\\Books\\Motivational\\RichDadAndPoorDad.txt");
			  
			try {
				Scanner sc = new Scanner(f);
				 while(sc.hasNextLine()) {
					  System.out.println(sc.nextLine());
				 }
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		 }
		  public void readMindFullToMindful() {
			  File f = new File("D:\\Project1\\Books\\Motivational\\MindFullToMindful.txt");
			  try {
				Scanner sc = new Scanner (f);
				while(sc.hasNextLine()) {
					System.out.println(sc.nextLine());
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} 
		  }
		  
		  public void readAllIsNotWell() {
			  File f = new File("D:\\Project1\\Books\\Motivational\\AllIsNotWell.txt");
			  try {
				Scanner sc = new Scanner (f);
				while(sc.hasNextLine()) {
					System.out.println(sc.nextLine());
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
		  }
		  }
		  
		  public void readFirstHead() {
			  File f = new File("D:\\Project1\\Books\\Java\\FirstHead.txt");
			  try {
				Scanner sc = new Scanner (f);
				while(sc.hasNextLine()) {
					System.out.println(sc.nextLine());
					
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
		  }
		  }
		  
		  public void readEffectiveJava() {
			  File f = new File("D:\\Project1\\Books\\Java\\EffectiveJava.txt");
			  try {
				Scanner sc = new Scanner (f);
				while(sc.hasNextLine()) {
					System.out.println(sc.nextLine());
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			   }
			  }
		  
		  public void readTheMillionaireNextDoor()
		  {
			  File f = new File("D:\\Project1\\Books\\Finance\\TheMillionaireNextDoor.txt");
			 try {
				 Scanner sc = new Scanner(f);
				 while (sc.hasNextLine()) {
					 System.out.println(sc.nextLine());
				 }
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			   
		  }
		  
		  public void readTheRichestManInBabylon() {
			  File f = new File("D:\\Project1\\Books\\Finance\\TheRichestManInBabylon.txt");
			  
			try {
				Scanner sc = new Scanner(f);
				while (sc.hasNextLine()) {
					System.out.println(sc.nextLine());
					
				}
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		  }

}
