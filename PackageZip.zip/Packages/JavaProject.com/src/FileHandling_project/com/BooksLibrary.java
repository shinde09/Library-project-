package FileHandling_project.com;

import java.util.Scanner;

public class BooksLibrary {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		System.out.println("<----- Welcome to book Library ----->");
		System.out.println();
		System.out.println("Select Type of Books ....");
		System.out.println("1. Motivational Books" + "\n2. Java Books" +
		"\n3. Finance Books" );
		
		
		int Select = sc.nextInt();
		switch(Select){
		case 1: 
			System.out.println("Welcome to Motivational Books Directory ");
			System.out.println("Select Book ....");
			System.out.println(" 1.MindSet " + "\n 2.Rich Dad and Poor Dad "+
			"\n 3.Mind full to MindFul "+"\n 4.All is not well");
			
			int M1 = sc.nextInt();
			if(M1==1) {
				Books1 B1 = new Books1();
			    B1.readMindsetBook();
			}
			else if(M1 ==2) {
				Books1 B2 = new Books1();
				B2.readRichDadAndPoorDadBook();
			}
			else if(M1 ==3) {
				Books1 B3 = new Books1();
				B3.readMindFullToMindful();
			}
			else if(M1==4){
				Books1 B4 = new Books1();
				B4.readAllIsNotWell();
			}else {
				System.out.println("Invalid Choice ...!");
			}
			break;
			
		case 2 :
			System.out.println("Welcome to Java Books Directory");
			System.out.println("Select Book....");
			
			System.out.println("1. first Head" + "\n2. Effective Java");
			
			int M2 = sc.nextInt();
			if(M2==1) {
				Books1 C1 = new Books1();
				C1.readFirstHead();
			}
			else if(M2==2){
				Books1 C2 = new Books1();
				C2.readEffectiveJava();
			}else {
				System.out.println("Invalid Choice ...!");
			}
			break;
			
		case 3: 
			System.out.println("Welcome to Finance Books Directory");
			System.out.println("Select Book....");
			System.out.println("1. TheMillionaireNextDoor " + "\n2. TheRichestManInBabylon ");
			
			int M3 = sc.nextInt();
			if(M3==1) {
				Books1 D1 = new Books1();
				D1.readTheMillionaireNextDoor();
			}
			else if(M3==2){
				Books1 D2 = new Books1();
				D2.readTheRichestManInBabylon();
			}else {
				System.out.println("Invalid Choice ...!");
			}
			break;
			
		}
	}

}
