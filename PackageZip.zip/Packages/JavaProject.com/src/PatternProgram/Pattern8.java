package PatternProgram;

public class Pattern8 {

	public static void main(String[] args) {
		int lines=5;
		String s1="*";
		for (int i = 0; i < lines; i++) {
			System.out.println(s1);
			s1=s1+"*";
			
		}

	}

}
