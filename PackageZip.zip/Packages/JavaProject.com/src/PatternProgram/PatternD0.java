package PatternProgram;

public class PatternD0 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int line=5,star=1,mid=(line+1)/2;

	}

}
