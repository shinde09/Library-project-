package PatternProgram;

public class PatternA3 {

	public static void main(String[] args) {
		int lines=5;
		int starCount=9;
		int space=0;
		for (int i = 0; i < lines; i++) {
			for (int j = 0; j < space; j++) {
				System.out.print(" ");
				
			}
			for (int j = 0; j < starCount; j++) {
				System.out.print("*");
				
			}
			System.out.println();
			starCount=starCount-2;
			space++;
			
			
		}

	}

}
