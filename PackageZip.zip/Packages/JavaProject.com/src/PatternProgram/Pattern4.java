package PatternProgram;

public class Pattern4 {

	public static void main(String[] args) {
		int lines=5;
		int count=5;
		char c='A';
		for (int i = 0; i < lines; i++) {
			for (int j = 0; j < count; j++) {
				System.out.print(" "+c);
				
			}
			System.out.println();
			count--;
			c++;
			
		}

	}

}
