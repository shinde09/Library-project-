package PatternProgram;

public class Pattern1 {
	public static void main(String[] args) {
		int lines=5;
		int starCount=1;
		for (int i = 0; i < lines; i++) {
			for (int j = 0; j < starCount; j++) {
				System.out.print(" *");
				
			}
			System.out.println();
			starCount++;
			
		}
	}

}
