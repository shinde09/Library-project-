package PatternProgram;

public class PatternA1 {

	public static void main(String[] args) {
		int line=5;
		int space=0;
		int starCount=5;
		for (int i = 0; i < line; i++) {
			for (int j = 0; j < space; j++) {
				System.out.print(" ");
				
			}
			for (int j = 0; j < starCount; j++) {
				System.out.print("*");
				
			}
			System.out.println();
			starCount--;
			space++;
			
		}

	}

}
