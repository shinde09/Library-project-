package PatternProgram;

public class Pattern7 {

	public static void main(String[] args) {
		int lines=5;
		String stars="i*!*i";
		for (int i = 0; i < lines; i++) {
			System.out.println(stars);
			
		}

	}

}
