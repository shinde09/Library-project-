package PatternProgram;

public class PatternA7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int line=5;
		int starCount=5;
		for (int i = 1; i <= line; i++) {
			for (int j = 1; j <= starCount; j++) {
				if (i==line || j==starCount||j==1) {
					System.out.print("*");
				} else {
					System.out.print(" ");
                    }
			}
			System.out.println();
			
		}


	}

}
