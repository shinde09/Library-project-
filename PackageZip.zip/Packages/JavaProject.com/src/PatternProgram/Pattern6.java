package PatternProgram;

public class Pattern6 {

	public static void main(String[] args) {
		int lines=5;
		int count=5;
		for (int i = 0; i < lines; i++) {
			for (int j = 0; j < count; j++) {
				System.out.print("*");
		 }
			System.out.println();
			
		}

	}

}
