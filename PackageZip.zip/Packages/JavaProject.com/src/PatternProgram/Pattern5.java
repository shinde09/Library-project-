package PatternProgram;

public class Pattern5 {

	public static void main(String[] args) {
		int lines=5;
		int count=1;
		for (int i = 0; i < lines; i++) {
			for (int j = 0; j < count; j++) {
				System.out.print(" "+count);
				
			}
			System.out.println();
			count++;
			
		}
		

	}

}
