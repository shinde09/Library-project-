package PatternProgram;

public class Pattern3 {

	public static void main(String[] args) {
		int lines=5;
		int starCount=1;
		char c='A';
		for (int i = 0; i < lines; i++) {
			for (int j = 0; j < starCount; j++) {
				System.out.print(" "+c);
				
			}
			System.out.println();
			starCount++;
			c++;

	   }
	}
}
