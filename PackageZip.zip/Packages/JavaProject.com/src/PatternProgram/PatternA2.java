package PatternProgram;

public class PatternA2 {

	public static void main(String[] args) {
		int line=5;
		int starCount=1;
		int space=4;
		for (int i = 0; i < line; i++) {
			for (int j = 0; j < space; j++) {
				System.out.print(" ");
			}
			for (int j = 0; j < starCount; j++) {
				System.out.print("*");
				
			}
			System.out.println();
			starCount=starCount+2;
			space--;
			
		}

	}

}
