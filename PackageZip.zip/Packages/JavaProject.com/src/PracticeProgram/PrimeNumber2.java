package PracticeProgram;

public class PrimeNumber2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=171,count=0;
		for (int i = 2; i < num/2; i++) {
			if (num%i==0) {
				System.out.println("Not Prime");
				count=1;
				break;
			}
		}
		if (count==0) {
			System.out.println("Prime Number");
		}
		
	}

}
