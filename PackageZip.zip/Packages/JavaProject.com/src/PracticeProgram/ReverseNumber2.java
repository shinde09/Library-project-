package PracticeProgram;

public class ReverseNumber2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num=9471;
		int res=0;
		while (num>0) {
		  res=num%10;
		 num=num/10;
			
		}
		System.out.print(res);

    }
}
