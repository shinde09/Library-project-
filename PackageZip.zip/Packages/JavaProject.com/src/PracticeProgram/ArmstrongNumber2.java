package PracticeProgram;

public class ArmstrongNumber2 {
	
	// 3 digits only

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=403,temp=num,res=0,sum=0;
		//for (int i = 0; i <= num; i++) {
		while (num>0) {
			
		
			res=num%10;
			num=num/10;
			sum=sum+res*res*res;
			
		}
		//System.out.println(sum);
		if (temp==sum) {
			System.out.println("ArmStrong "+sum);
		} else {
			System.out.println("Not ArmStrong");

		}

	}

}
