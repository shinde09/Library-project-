package PracticeProgram;

public class PerfectNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=7;
		int sum=0;
		
		for(int i=1;i<num;i++) {
			if(num%i==0 && num%num==0) {
				sum=sum+i;
			}
			
		}
		if(num==sum) {
			System.out.println("This is perfect number");
		}else {
			System.out.println("not Perfect");
		}
	}

}
