package PracticeProgram;

public class ArrayDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] courses=new String[4];
		courses[0]="Java";
		courses[1]="SQL";
		courses[2]="Manual";
		courses[3]="C++";
		for (int i = 0; i < courses.length; i++) {
			System.out.print(courses[i]+" ");
		}
		System.out.println();
		System.out.println("==============================");
		
		for (String s : courses) {
			System.out.print(s+" ");
		}
		System.out.println();
		
		System.out.println("==============================");
		for (int i =3	; i >=0; i--) {
			System.out.print(courses[i]+" ");
		}
   }

}
