package PracticeProgram;

import java.util.Scanner;

public class ArrayDemo4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter Array Size");
		int size=sc1.nextInt();
		int []arr1=new int[size];
		System.out.println("Enter Array Element");
		int sum=0;
		for (int i = 0; i < size; i++) {
			arr1[i]=sc1.nextInt();
			
			sum=sum+arr1[i];
			}
			System.out.println(sum);
//		//int arr1[]= {10,20,30,40};
//	int sum=0;
//		for (int i = 0; i < arr1.length; i++) {
//			sum=sum+arr1[i];
//		}
		//System.out.println(sum);
		}
	}


