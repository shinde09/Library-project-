package PracticeProgram;

public class Swapping {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10,b=20,c=0;
		// 1st
//		c=a;
//		a=b;
//		b=c;
		
		//2nd
//		a=a+b;
//		b=a-b;
//		a=a-b;
		
		//3rd
		a=a*b;
		b=a/b;
		a=a/b;
		System.out.println("A is "+a);
		System.out.println("B is "+b);

	}

}
