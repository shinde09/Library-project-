package PracticeProgram;

import java.util.Scanner;

public class FibonacciSeries {

	public static void main(String[] args) {
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter Number");
		int num=sc1.nextInt();
		int a=0,b=1,c=0;
		for (int i = 0; i < num; i++) {
			a=b;
			b=c;
			c=a+b;
			System.out.println(c);
		}

	}

}
