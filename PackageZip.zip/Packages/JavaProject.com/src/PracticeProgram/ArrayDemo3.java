package PracticeProgram;

public class ArrayDemo3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char []cArray= {'A','B','C','D'};
		for (int i = 0; i < cArray.length; i++) {
			System.out.print(cArray[i]+" ");
		}

	}

}
