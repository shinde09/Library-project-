package PracticeProgram;

public class factorial2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int fact=5;
		for (int i = 1; i < 5; i++) {
			fact=fact*i;
		
		}
		System.out.println("Factorial "+fact);

	}

}
