package PracticeProgram;

public class CommandLineArgs {

	public static void main(String[] args) {
		for (String t : args) {
			System.out.println(t);
		}

	}

}
