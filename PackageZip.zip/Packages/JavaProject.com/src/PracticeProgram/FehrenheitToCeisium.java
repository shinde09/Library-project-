package PracticeProgram;

import java.util.Scanner;

public class FehrenheitToCeisium {

	public static void main(String[] args) {

		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter temp in Fehrenheit");
		float temp=sc1.nextFloat();
		temp=((temp-32)*5)/9;
		System.out.println(temp +" in celsium");

	}

}
