package PracticeProgram;

public class FindGreatestNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10,b=30,c=20;
		if (a>b && a>c) {
			System.out.println("A is greater");
		} else if(b>c){
            System.out.println("B is greater");
		}else {
			System.out.println("C is greater");
		}

	}

}
