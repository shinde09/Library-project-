package PracticeProgram;

public class ComparisionNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10,b=20;
		if (a==b) {
			System.out.println("Same Numbers");
		} else {
            System.out.println("Not same");
		}

	}

}
