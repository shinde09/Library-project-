package PracticeProgram;

import java.util.Iterator;
import java.util.Scanner;

public class ArrayAddition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Scanner sc1=new Scanner(System.in);
//		int num=sc1.nextInt();
		int sum=0;
		
		int []arr1=new int[5];
		arr1[0]=10;
		arr1[1]=20;
		arr1[2]=30;
        arr1[3]=40;
		arr1[4]=50;
		//System.out.println(arr1[4]);

		for (int i = 0; i < arr1.length; i++) {
			System.out.print(arr1[i]+" ");
			sum=sum+arr1[i];
			
		}
		System.out.println();
		System.out.println("Addition of array "+sum);

		

	}

}
