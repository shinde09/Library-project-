package PracticeProgram;

public class Merge2_Array {
	public static void main(String[] args) {
		int []arr1= {10,20,30,40};
		int []arr2= {50,60,70,80};
		int a1=arr1.length;
		int b1=arr2.length;
		int c1=a1+b1;
		int []arr3=new int[c1];
		
	}

}
