package PracticeProgram;

import java.util.Scanner;

public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int fact=1;
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter Number");
		int num=sc1.nextInt();
		for (int i = 1; i <= num; i++) {
			fact=fact*i;
		}
		System.out.println(fact);

	}

}
