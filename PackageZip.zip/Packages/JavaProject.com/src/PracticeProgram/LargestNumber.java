package PracticeProgram;

import java.util.Scanner;

public class LargestNumber {

	public static void main(String[] args) {
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter 1st Number");
		int num1=sc1.nextInt();
		System.out.println("Enter 2nd Number");
		int num2=sc1.nextInt();
		System.out.println("Enter 3rd Number");
		int num3=sc1.nextInt();
		if (num1>num2 && num1>num3) {
			System.out.println("1st Number is largest");
		} else if(num2>num3) {
             System.out.println("2nd Number is largest");
		}else {
			System.out.println("3rd Number is largest12");
		}
//		int num=num1>num2?(num1>num3?num1:num3):(num2>num3? num2:num3);
//		System.out.println("\n"+num);

		
	}

}
