package PracticeProgram;

import java.util.Scanner;

public class EvenOdd {

	public static void main(String[] args) {

		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter Number");
		int num=sc1.nextInt();
		if (num%2==0) {
			System.out.println("Even");
		} else {
            System.out.println("Odd");
		}
	}

}
