package PracticeProgram;

import java.util.Scanner;

public class MultiplicationTable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int mul=1;
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter Number");
		int n=sc1.nextInt();
		for (int i = 1; i <= 10; i++) {
			mul=n*i;
			System.out.println(mul);
		}

	}

}
