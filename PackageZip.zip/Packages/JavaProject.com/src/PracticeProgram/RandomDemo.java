package PracticeProgram;

public class RandomDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i = 0; i <5; i++) {
		//	System.out.println(Math.random()*100);
		System.out.println((int)(Math.random()*100));	
		}

	}

}
