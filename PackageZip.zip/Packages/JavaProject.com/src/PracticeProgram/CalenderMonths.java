package PracticeProgram;

import java.util.Scanner;

public class CalenderMonths {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			Scanner sc1=new Scanner(System.in);
			System.out.println("Enter Total days of Month");
			int days=sc1.nextInt();
			if (days==31) {
				System.out.println("January\nMarch\nMay\nJuly\nAugust\nOctober\nDecember");
//				System.out.println("March");
//				System.out.println("May");
//				System.out.println("July");			
//				System.out.println("August");
//				System.out.println("October");
//				System.out.println("December");

	     } else if(days==30){
				System.out.println("April\nJune\nSeptember\nNovember");
//				System.out.println("June");
//				System.out.println("September");
//				System.out.println("November");
	    
	     }else if (days==28||days==29) {
				
	    	    System.out.println("February");

			}else {
	    	    System.out.println("Invalid Choice..!");

			}
			sc1.close();
    }
}

