package PracticeProgram;

public class SecondHigh {

	public static void main(String[] args) {
		int a=71,b=15,c=29;
	if (a>b && a<c || a<b && a>c ) {
		System.out.println("Second Largest Number is "+a);
		
    }else if (b>a && b<c || b<a && b>c) {
		System.out.println("Second Largest Number is "+b);
    	
	}else {
		System.out.println("Second Largest Number is "+c);
		
	   }

	}
}
