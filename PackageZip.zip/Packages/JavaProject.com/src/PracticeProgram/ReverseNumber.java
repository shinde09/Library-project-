package PracticeProgram;

import java.util.Scanner;

public class ReverseNumber {

	public static void main(String[] args) {
          
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter Number");
		int num=sc1.nextInt();
		int temp = 0;

		while (num>0) {
			temp=num%10;
			num=num/10;
			System.out.print(temp);

		}
	}

}
