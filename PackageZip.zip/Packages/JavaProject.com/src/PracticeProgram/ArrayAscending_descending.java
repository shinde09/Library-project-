package PracticeProgram;

public class ArrayAscending_descending {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int []arr1=new int[5];
		//int []arr2=new int[5];

		int temp=0;
		arr1[0]=50;
		arr1[1]=23;
		arr1[2]=30;
        arr1[3]=90;
		arr1[4]=67;
		for (int i = 0; i < arr1.length; i++) {
			for (int j = i+1; j < arr1.length; j++) {
				if (arr1[i]>arr1[j]) {
					temp = arr1[i];  
					arr1[i] = arr1[j];  
					arr1[j] = temp; 
				}
				
			}
			System.out.println(arr1[i]);
		}
		

	}

}
