package PracticeProgram;

public class Square {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sqr=1;
		
      for (int i = 1; i <=10; i++) {
		sqr=i*i;
		System.out.println(sqr);
	  }
  }
}
