package JavaExamples;

public class Char_change {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="GOOGLE";
		char[] arr=s.toCharArray();
		for(int i=0;i<arr.length;i++) {
			int index=i;
			for(int j=0;j<arr.length;j++) {
				System.out.print(arr[index]);
				index++;
				index=index % arr.length;
			}
			System.out.println();
		}

	}

}
