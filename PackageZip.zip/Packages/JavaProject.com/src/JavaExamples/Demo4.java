package JavaExamples;

import java.util.Scanner;

public class Demo4 {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter Value1");
		int value1=scanner.nextInt();
		System.out.println("Enter Value2");
		int value2=scanner.nextInt();
		
		if (value1%value2==0) {
			System.out.println("Value1 is divisible by value2 "+value1/value2);
		} else {
			System.out.println("Value1 is NOT divisible by value2 ");
         }
		scanner.close();
	}

}
		
		
         		


