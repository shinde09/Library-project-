package JavaExamples;

import java.util.Scanner;

public class p6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Distsnce");
		int d=sc.nextInt();
		System.out.println("Enter Time in Hr");
		int t=sc.nextInt();
		
		int speed=d/t;
		System.out.println("Speed is "+speed+" kmph");


	}

}
