package JavaExamples;

public class ReverseExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=123456;
		while (num>0) {
			int res=num%10;
			num=num/10;
			System.out.print(res);
	
          }
     }
}
