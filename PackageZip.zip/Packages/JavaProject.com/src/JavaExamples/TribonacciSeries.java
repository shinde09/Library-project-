package JavaExamples;

public class TribonacciSeries {

	public static void main(String[] args) {
		int num=20;
        int a=0,b=0,c=1;
        int d=0,count=0;
        System.out.println(a+"\n"+b+"\n"+c);
		for (int i = 4; i <= num; i++) {
        a=b;//0,1,0,1
		b=c;//1,0,1,2
		c=d;//0,1,2,3
		d=a+b+c;//1,2,3,6
		System.out.println(d);
		count++;
     }
	    System.out.println("Total Count-->"+count);	
  }
}
