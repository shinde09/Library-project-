package JavaExamples;

public class OddEven {
public static void main(String[] args) {
	int num=36;
//	if (num%2==0) {
//		System.out.println("Even");
//	} else {
//		System.out.println("Odd");
//
//	}
	
	while (num%2==0) {
		System.out.println("Even");
		return;
	}
	System.out.println("Odd");
}
}
