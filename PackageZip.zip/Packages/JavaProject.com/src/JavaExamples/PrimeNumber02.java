package JavaExamples;

public class PrimeNumber02 {
	public static void main(String[] args) {
        int num1=1,num2=100,count1 = 0;
		for (int i = num1; i <= num2; i++){
			int count=0;
			for(int j = 2; j < i ; j++){
              if (i%j==0){
	             count++;
	             
              }
            }//internal for loop end
			if(count==0) {
				count1++;
				System.out.println(i);
			}
         }//1st for loop end
		
		System.out.println("Total count -->"+count1);
   }

}
