package JavaExamples;

public class Account {
	String AcHolderName;
	int acNumber;
	String password;
	int balance;
	public Account(String acHolderName, int acNunber, String password, int balance) {
		super();
		AcHolderName = acHolderName;
		this.acNumber = acNunber;
		this.password = password;
		this.balance = balance;
	};
public void showAccountdetails() {
	System.out.println("Account Holder Name -->"+AcHolderName);
	System.out.println("Account Number-->"+acNumber);
	System.out.println("Password-->"+password);
	System.out.println("Available Balance-->"+balance);
	
}
}
