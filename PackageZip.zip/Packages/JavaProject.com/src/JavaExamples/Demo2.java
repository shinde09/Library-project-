package JavaExamples;

public class Demo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int String =10;
		double Scanner=20.0;
		 double total=String*Scanner;
		System.out.println(total);

	}

}
