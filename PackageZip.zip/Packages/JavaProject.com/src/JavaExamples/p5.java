package JavaExamples;

public class p5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int d=350;
		int t=180/60;
		double speed=d/t;
		System.out.println("Speed Of Train is "+speed+" kmph");

	}

}
