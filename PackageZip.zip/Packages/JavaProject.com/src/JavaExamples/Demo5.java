package JavaExamples;

public class Demo5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		int a=0;
//		do {
//			System.out.println("Execution "+a);
//			a++;
//		} while (a<1);
		
		
		//program 2
		
		int j=3;
		for (; j >= 0; j--) {
			System.out.println(j);
		}

	}

}
