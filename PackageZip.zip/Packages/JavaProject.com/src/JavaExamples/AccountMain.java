package JavaExamples;

public class AccountMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account ac=new Account("Mauli Shinde",123456789 , "Shinde@09", 2000);
		Account ac1=new Account("Danny Shinde",907556789 , "Danny@09", 3000);

		ac.showAccountdetails();
		ac1.showAccountdetails();

	}

}
