package JavaExamples;

public class DivisibleExample {

	public static void main(String[] args) {
		int a=1,count=0;
		int b=100;
		for (int i = 1; i <= b; i++) {
			if (i%7==0) {
				count++;
				//System.out.println(i+" "+count);

			}

		}
		System.out.println("Total Count-->"+count);


	}

}
