package JavaExamples;

public class FizzBuzzExample {

	public static void main(String[] args) {
		int num=100;
		int a=0,b=0,c=0;
	     for (int i = 1; i <=num; i++) {
	    	if (i%5==0 && i%3==0) {
				System.out.println("FizzBuzz");
				a++;
			} else if(i%5==0){
               System.out.println("Fizz"); 
               b++;
			}else if (i%3==0) {
				System.out.println("Buzz");
				c++;
			}else {
				System.out.println(i);
			}
	  }
	    	System.out.println("Total no of FizzBuzz->"+a);
	    	System.out.println("Total No of Fizz-->"+b);
	    	System.out.println("Total No of Buzz-->"+c);



   }
}
