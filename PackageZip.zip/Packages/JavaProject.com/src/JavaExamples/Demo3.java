package JavaExamples;

import java.util.Scanner;

public class Demo3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 1st Number");
		int num1=sc.nextInt();
		System.out.println("Enter 2nd Number");
		int num2=sc.nextInt();
		
		for (int i = num1; i <num2; i++) {
			//num1++;
			//System.out.println(num1);
			System.out.println(i);
			
			
		}
		sc.close();

	}

}
