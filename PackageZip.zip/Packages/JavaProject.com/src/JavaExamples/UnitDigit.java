package JavaExamples;

public class UnitDigit {

	public static void main(String[] args) {
		int num=2053;
		int unitDigit=0;
		
		unitDigit=num%10;
		System.out.println("Unit Digit Or last digit "+unitDigit);

	}

}
