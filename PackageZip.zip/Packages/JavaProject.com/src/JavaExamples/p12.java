package JavaExamples;

import java.util.Scanner;

public class p12 {

	public static void main(String[] args) {
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter amount in Rupees");
		int amount=sc1.nextInt();
		
		System.out.println("Total amount in Doller "+amount/75+"$");

	}

}
