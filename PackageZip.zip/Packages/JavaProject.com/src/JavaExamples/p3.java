package JavaExamples;

import java.util.Scanner;

public class p3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Meters");
		double meters=sc.nextDouble();
		
		System.out.println("Total Kilometers-->"+meters/1000+" km");

	}

}
