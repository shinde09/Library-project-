package JavaExamples;

public class StrongNumber {

	public static void main(String[] args) {

		int n=40585;          //Ex- 1!=1,2!=2,145=1!+4!+5!=145,40585
		int temp=n;
		int sum=0,rem;
		while (n>0) {
			 rem=n%10;
			int fact=1;
			for (int i = 1; i <= rem; i++) {
				fact=fact*i;
			}
			sum=sum+fact;
			n=n/10;
		}
		if (temp==sum) {
			System.out.println("Strong Number");
		}
		else {
			System.out.println("Not a Strong Number");
		}
	}

}
