package JavaExamples;

import java.util.Scanner;

public class p15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter text");
		String lc=sc1.next();
		
		// Or
		//String lc="qspiders hadapsar";
		System.out.println(lc.toUpperCase());

	}

}
