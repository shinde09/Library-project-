package JavaExamples;

public class PrimeRange {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1=1,num2=100,count2=0;
		for (int i = num1; i <= num2; i++) {
			int count=0;
			for (int j = 2; j < i; j++) {
				if (i%j==0) {
					count=count+1;
				}
				
			}
			if (count==0) {
				System.out.println(i);
			}
			
		}

	}

}
