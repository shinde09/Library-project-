package JavaExamples;

import java.util.Scanner;

public class p13 {//celcius to fahrenhait conversion

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter Temperature in celcium");
		int celcium=sc1.nextInt();
		
		double F=celcium*(1.8)+32;//   9/5=1.8
		System.out.println("Temp in Fehrenheit "+F);


	}

}
