package JavaExamples;

import java.util.Scanner;

public class p14 {

	public static void main(String[] args) {
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter 1st Subject Marks");
		int sub1=sc1.nextInt();
		System.out.println("Enter 2nd Subject Marks");
		int sub2=sc1.nextInt();
		System.out.println("Enter 3rd Subject Marks");
		int sub3=sc1.nextInt();
		System.out.println("Enter 4th Subject Marks");
		int sub4=sc1.nextInt();
		System.out.println("Enter 5th Subject Marks");
		int sub5=sc1.nextInt();
		
		double total=sub1+sub2+sub3+sub4+sub5;
		double percentage=total/5;
		System.out.println("Total Marks is "+total+" marks");
		System.out.println("Percentage is "+percentage+" %");
		
	}

}
