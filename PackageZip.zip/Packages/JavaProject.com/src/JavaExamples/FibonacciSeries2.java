package JavaExamples;

public class FibonacciSeries2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int p1=0,p2=1,p3;
		int count=0;
		int num=7;
		for (int i = 0; i < num; i++) {
			p3=p1+p2;
			if (p3%2==0) {
				System.out.println(p3+"  Even Number");
			} else {
                System.out.println(p3+"  Odd Number");
			}
			count++;
			p1=p2;
			p2=p3;
		}
		System.out.println("Total Count is --> "+count);

	}

}
