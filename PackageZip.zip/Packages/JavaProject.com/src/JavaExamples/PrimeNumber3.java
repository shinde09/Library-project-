package JavaExamples;

public class PrimeNumber3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=23,count=0;
		for (int i = 2; i < num; i++) {
			if (num%i==0) {
				count++;
			}
		}
		if (count==0) {
			System.out.println("Prime Number");
		} else {
          System.out.println("Not Prime Number");
		}

	}

}
