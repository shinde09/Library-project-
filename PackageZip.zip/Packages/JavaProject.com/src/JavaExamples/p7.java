package JavaExamples;

import java.util.Scanner;

public class p7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter Radius ");
		int radius=sc1.nextInt();
		
		double perimeter=2*3.14*radius;
		System.out.println("Perimeter is "+perimeter);
		

	}

}
