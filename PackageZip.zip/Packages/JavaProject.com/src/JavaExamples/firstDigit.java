package JavaExamples;

public class firstDigit {

	public static void main(String[] args) {
		int num=2053;
		int firstDigit=0;
		while (num>0) {
			firstDigit=num%10;//3,5,0
			num=num/10;//205,20,2
			
		}
		System.out.println(firstDigit);

	}

}
