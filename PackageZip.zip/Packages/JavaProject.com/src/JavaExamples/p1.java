package JavaExamples;

import java.util.Scanner;

public class p1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Seconds");
		int seconds=sc.nextInt();
		
		int minuts=seconds/60;
		System.out.println("Minuts is "+minuts);

	}

}
