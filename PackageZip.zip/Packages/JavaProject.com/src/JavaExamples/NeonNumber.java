package JavaExamples;

public class NeonNumber {  //n=9->9*9=81->8+1=9 i.e, Neon

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=9;
		int sqr=num*num;
		int sum=0;
		while (sqr>0) {
		int	res=sqr%10;
			sum=sum+res;
			sqr=sqr/10;
		}
		if (num==sum) {
			System.out.println("Neon Number");
		} else {
            System.out.println("Not Neon");
		}

	}

}
