package JavaExamples;

import java.util.Scanner;

public class NegativeNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter Positive Number");
		int number=sc1.nextInt();
		
		int NegativeNumber=number*(-1);
		System.out.println("Negative Number "+NegativeNumber);

	}

}
