package JavaExamples;

public class ReverseNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=13579;
		int reverse=0;
		int res=0;
		while (num>0) {//141,14,1
			res=num%10;//1,4,1
			reverse=reverse*10+res;//0+1=1,1*10+4=14,14*10+1=141
			num=num/10;//141/10=14,14/10=1
		}
		System.out.println(reverse);

	}

}
