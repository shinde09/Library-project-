package JavaExamples;

public class ArmStrong {

	public static void main(String[] args) {
         int n=153;//armStrong means--> if num is 3 digit then-> 1 cube(1)+5 cube(125)+3 cube(27)=153
		int sum=0,r,temp=n;                           // if num 2 digit then->1st square+2nd square
		while (n>0) {
			r=n%10;
			sum=sum+r*r*r;
			n=n/10;
		}
		if (temp==sum) {
			System.out.println("ArmStrong Number");
		}
		else {
			System.out.println("Not a ArmStrong");
		}

	}

}
