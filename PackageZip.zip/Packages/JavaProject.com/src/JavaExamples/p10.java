package JavaExamples;

import java.util.Scanner;

public class p10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter Number");
		int number=sc1.nextInt();
		
		int num1=number-1;
		int num2=number+1;
		System.out.println(num1+","+num2);

	}

}
