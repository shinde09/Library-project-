package JavaExamples;

import java.util.Scanner;

public class p9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter Principle amount");
		int principle=sc1.nextInt();
		System.out.println("Enter Rate of Interest");
		int interest=sc1.nextInt();
		System.out.println("Enter Time Duration in Months ");
		int months=sc1.nextInt();


		
		double amount=principle+(principle*interest*months)/100;
		System.out.println("The Total Amount is "+amount);
        sc1.close();
	}
	

}
