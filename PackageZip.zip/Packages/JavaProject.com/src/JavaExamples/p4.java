package JavaExamples;

import java.util.Scanner;

public class p4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter kilometers");
		double km=sc.nextDouble();
		
		System.out.println("Total meters-->"+km*1000+" meter");


	}

}
