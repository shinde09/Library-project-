package JavaExamples;

public class ReplaceString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="qspiders shinde";
		//System.out.println(s1.replace("s", "$"));
		String s2=s1.replace("s", "$");
		System.out.println(s2);
		System.out.println(s2.replace("i", "!"));
	

	}

}
