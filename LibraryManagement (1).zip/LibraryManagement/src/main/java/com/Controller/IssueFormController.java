package com.Controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/IssueFormController")
public class IssueFormController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public IssueFormController() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String name=(String) request.getParameter("studentname");
		String bookname=(String) request.getParameter("book");
		String doi=(String) request.getParameter("doi");
		
		String id= request.getParameter("id");
		int id1=Integer.parseInt(id);
		
		 String user="root";
		 String password="root";
		 String url="jdbc:mysql://localhost:3306/jdbc_projects";
		
			try {
			Class.forName("com.mysql.cj.jdbc.Driver");  
			  
			//step2 create  the connection object  
			Connection con=DriverManager.getConnection(url,user,password ); 
			  
	PreparedStatement st = con.prepareStatement("insert into library(ID,STUDENTNAME,BOOKS,DATE_OF_ISSUE) values(?,?,?,?)");
  
           
            st.setInt(1, Integer.valueOf(request.getParameter("id")));
  
            // Same for second parameter
            st.setString(2, request.getParameter("studentname"));
            st.setString(3, request.getParameter("book"));
            st.setString(4, request.getParameter("doi"));
             // Execute the insert command using executeUpdate()
            // to make changes in database
            int rowafffected =st.executeUpdate();
            if(rowafffected>0) {
            System.out.println(rowafffected+"Row inserted ");
            request.setAttribute("id", Integer.valueOf(request.getParameter("id")));
            request.setAttribute("name",(request.getParameter("studentname")));
            request.setAttribute("book", (request.getParameter("book")));
            request.getRequestDispatcher("DisplayStudentInfo.jsp").forward(request, response);
            }
            else {
            	System.out.print("No row inserted");
            	request.setAttribute("error","No row inserted !!Try again");
                 request.getRequestDispatcher("Error.jsp").forward(request, response);}
            st.close();
			con.close();
			  
			}catch(Exception e)  {
				request.setAttribute("error",e);
                request.getRequestDispatcher("Error.jsp").forward(request, response);
     }
	}

}
